/*
 * telemetryTransmitter.h
 *
 *  Created on: Oct 26, 2024
 *      Author: gslee
 */

#ifndef INC_TELEMETRYTRANSMITTER_H_
#define INC_TELEMETRYTRANSMITTER_H_

#define BAUDRATE 57600

#endif /* INC_TELEMETRYTRANSMITTER_H_ */
